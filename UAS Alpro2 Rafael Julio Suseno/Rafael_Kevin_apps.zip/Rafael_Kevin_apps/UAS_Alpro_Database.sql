-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               10.4.32-MariaDB - mariadb.org binary distribution
-- Server OS:                    Win64
-- HeidiSQL Version:             12.10.0.7046
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;


-- Dumping database structure for sistem_jemput
CREATE DATABASE IF NOT EXISTS `sistem_jemput` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;
USE `sistem_jemput`;

-- Dumping structure for table sistem_jemput.anak
CREATE TABLE IF NOT EXISTS `anak` (
  `id` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `orang_tua_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `orang_tua_id` (`orang_tua_id`),
  CONSTRAINT `anak_ibfk_1` FOREIGN KEY (`orang_tua_id`) REFERENCES `orang_tua` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sistem_jemput.anak: ~2 rows (approximately)
INSERT INTO `anak` (`id`, `nama`, `orang_tua_id`) VALUES
	('R-002', 'Roki', 'R-002'),
	('T-001', 'Tido', 'T-001');

-- Dumping structure for table sistem_jemput.jadwal
CREATE TABLE IF NOT EXISTS `jadwal` (
  `tanggal` date NOT NULL,
  `anak_id` varchar(10) NOT NULL,
  `penjemput_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`tanggal`,`anak_id`),
  KEY `anak_id` (`anak_id`),
  KEY `penjemput_id` (`penjemput_id`),
  CONSTRAINT `jadwal_ibfk_1` FOREIGN KEY (`anak_id`) REFERENCES `anak` (`id`),
  CONSTRAINT `jadwal_ibfk_2` FOREIGN KEY (`penjemput_id`) REFERENCES `orang_tua` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sistem_jemput.jadwal: ~7 rows (approximately)
INSERT INTO `jadwal` (`tanggal`, `anak_id`, `penjemput_id`) VALUES
	('2025-05-26', 'T-001', 'T-001'),
	('2025-05-27', 'R-002', 'T-001'),
	('2025-05-27', 'T-001', 'R-002'),
	('2025-05-28', 'R-002', 'R-002'),
	('2025-05-28', 'T-001', 'T-001'),
	('2025-05-30', 'R-002', 'T-001'),
	('2025-05-30', 'T-001', 'R-002');

-- Dumping structure for table sistem_jemput.notifikasi
CREATE TABLE IF NOT EXISTS `notifikasi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pesan` text NOT NULL,
  `waktu` datetime DEFAULT NULL,
  `dibaca` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sistem_jemput.notifikasi: ~7 rows (approximately)
INSERT INTO `notifikasi` (`id`, `pesan`, `waktu`, `dibaca`) VALUES
	(6, 'Jadwal baru untuk tanggal 2025-05-28 telah dibuat', '2025-05-27 09:34:42', 0),
	(7, 'Jadwal baru untuk tanggal 2025-05-27 telah dibuat', '2025-05-27 09:35:09', 0),
	(8, 'Jadwal baru untuk tanggal 2025-05-28 telah dibuat', '2025-05-27 09:35:22', 0),
	(9, 'Jadwal baru untuk tanggal 2025-05-28 telah dibuat', '2025-05-27 09:35:58', 0),
	(10, 'Pertukaran jadwal: Tido pada 2025-05-28 akan dijemput oleh Tomi menggantikan Ramah', '2025-05-27 09:36:12', 0),
	(11, 'Pertukaran jadwal: Roki pada 2025-05-28 akan dijemput oleh Ramah menggantikan Tomi', '2025-05-27 09:36:29', 0),
	(12, 'Jadwal baru untuk tanggal 2025-05-30 telah dibuat', '2025-05-27 09:37:47', 0);

-- Dumping structure for table sistem_jemput.orang_tua
CREATE TABLE IF NOT EXISTS `orang_tua` (
  `id` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sistem_jemput.orang_tua: ~2 rows (approximately)
INSERT INTO `orang_tua` (`id`, `nama`) VALUES
	('R-002', 'Ramah'),
	('T-001', 'Tomi');

-- Dumping structure for table sistem_jemput.pertukaran
CREATE TABLE IF NOT EXISTS `pertukaran` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date DEFAULT NULL,
  `anak_id` varchar(10) DEFAULT NULL,
  `dari` varchar(10) DEFAULT NULL,
  `ke` varchar(10) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `waktu_pertukaran` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `anak_id` (`anak_id`),
  KEY `dari` (`dari`),
  KEY `ke` (`ke`),
  CONSTRAINT `pertukaran_ibfk_1` FOREIGN KEY (`anak_id`) REFERENCES `anak` (`id`),
  CONSTRAINT `pertukaran_ibfk_2` FOREIGN KEY (`dari`) REFERENCES `orang_tua` (`id`),
  CONSTRAINT `pertukaran_ibfk_3` FOREIGN KEY (`ke`) REFERENCES `orang_tua` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sistem_jemput.pertukaran: ~2 rows (approximately)
INSERT INTO `pertukaran` (`id`, `tanggal`, `anak_id`, `dari`, `ke`, `status`, `waktu_pertukaran`) VALUES
	(1, '2025-05-28', 'T-001', 'R-002', 'T-001', 'berhasil', '2025-05-27 09:36:12'),
	(2, '2025-05-28', 'R-002', 'T-001', 'R-002', 'berhasil', '2025-05-27 09:36:29');

-- Dumping structure for table sistem_jemput.tidak_bisa_jemput
CREATE TABLE IF NOT EXISTS `tidak_bisa_jemput` (
  `orang_tua_id` varchar(10) NOT NULL,
  `anak_id` varchar(10) NOT NULL,
  PRIMARY KEY (`orang_tua_id`,`anak_id`),
  KEY `anak_id` (`anak_id`),
  CONSTRAINT `tidak_bisa_jemput_ibfk_1` FOREIGN KEY (`orang_tua_id`) REFERENCES `orang_tua` (`id`),
  CONSTRAINT `tidak_bisa_jemput_ibfk_2` FOREIGN KEY (`anak_id`) REFERENCES `anak` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Dumping data for table sistem_jemput.tidak_bisa_jemput: ~0 rows (approximately)

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
