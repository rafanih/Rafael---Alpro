import datetime
import calendar
import json
import os
from datetime import date, timedelta
import time
import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
import sys
import socket
import threading
import queue
import mysql.connector

connection = mysql.connector.connect(
    host='localhost',
    database='sistem_jemput',
    user='root',
    password=''
)


class SistemPenjadwalanJemput:
    def __init__(self):
        self.orang_tua = {}  # Menyimpan data orang tua {id: {"nama": nama, "anak": [anak_id], "tidak_bisa_jemput": [anak_id]}}
        self.anak = {}  # Menyimpan data anak {id: {"nama": nama, "orang_tua_id": id}}
        self.jadwal = {}  # Menyimpan jadwal {tanggal: {anak_id: orang_tua_id}}
        self.notifikasi = []  # Menyimpan notifikasi untuk semua orang tua
        self.pertukaran = []  # Menyimpan riwayat pertukaran jadwal

        # Coba memuat data jika ada
        self.muat_data()

    def tambah_orang_tua(self, id, nama):
        cursor = connection.cursor()
        try:
            cursor.execute("INSERT INTO orang_tua (id, nama) VALUES (%s, %s)", (id, nama))
            connection.commit()
            return True, f"Orang tua {nama} (ID: {id}) berhasil ditambahkan"
        except mysql.connector.IntegrityError:
            return False, f"ID {id} sudah digunakan"
        except Exception as e:
            return False, f"Terjadi kesalahan: {str(e)}"

    def tambah_anak(self, id, nama, orang_tua_id):
        if not id or not nama or not orang_tua_id:
            return False, "Semua data harus diisi"
        
        cursor = connection.cursor()
        try:
            # Pastikan orang tua ada
            cursor.execute("SELECT 1 FROM orang_tua WHERE id = %s", (orang_tua_id,))
            if not cursor.fetchone():
                return False, f"Orang tua dengan ID {orang_tua_id} tidak ditemukan"

            # Tambahkan anak
            cursor.execute("INSERT INTO anak (id, nama, orang_tua_id) VALUES (%s, %s, %s)", (id, nama, orang_tua_id))
            connection.commit()
            return True, f"Anak {nama} (ID: {id}) berhasil ditambahkan"
        except mysql.connector.IntegrityError:
            return False, f"ID {id} sudah digunakan"
        finally:
            cursor.close()


    def atur_tidak_bisa_jemput(self, orang_tua_id, anak_id):
        """Orang tua tidak bisa jemput anak tertentu"""
        if orang_tua_id not in self.orang_tua:
            return False, f"Orang tua dengan ID {orang_tua_id} tidak ditemukan"
        if anak_id not in self.anak:
            return False, f"Anak dengan ID {anak_id} tidak ditemukan"

        cursor = connection.cursor()
        try:
            cursor.execute("""
                SELECT 1 FROM tidak_bisa_jemput WHERE orang_tua_id = %s AND anak_id = %s
            """, (orang_tua_id, anak_id))
            if cursor.fetchone():
                return False, f"{self.orang_tua[orang_tua_id]['nama']} sudah diatur tidak bisa jemput {self.anak[anak_id]['nama']}"

            cursor.execute("""
                INSERT INTO tidak_bisa_jemput (orang_tua_id, anak_id) VALUES (%s, %s)
            """, (orang_tua_id, anak_id))
            connection.commit()
            return True, f"{self.orang_tua[orang_tua_id]['nama']} tidak bisa jemput {self.anak[anak_id]['nama']}"
        finally:
            cursor.close()

    def hapus_tidak_bisa_jemput(self, orang_tua_id, anak_id):
        """Izinkan kembali orang tua menjemput anak"""
        if orang_tua_id not in self.orang_tua:
            return False, f"Orang tua dengan ID {orang_tua_id} tidak ditemukan"
        if anak_id not in self.anak:
            return False, f"Anak dengan ID {anak_id} tidak ditemukan"

        cursor = connection.cursor()
        try:
            cursor.execute("""
                DELETE FROM tidak_bisa_jemput WHERE orang_tua_id = %s AND anak_id = %s
            """, (orang_tua_id, anak_id))
            if cursor.rowcount == 0:
                return False, f"{self.orang_tua[orang_tua_id]['nama']} sudah bisa jemput {self.anak[anak_id]['nama']}"
            
            connection.commit()
            return True, f"{self.orang_tua[orang_tua_id]['nama']} sekarang bisa jemput {self.anak[anak_id]['nama']}"
        finally:
            cursor.close()
    
    def buat_jadwal_tanggal(self, tanggal):
        """Membuat jadwal penjemputan untuk tanggal tertentu"""
        cursor = connection.cursor(dictionary=True)
        try:
            tanggal_dt = datetime.datetime.strptime(tanggal, "%Y-%m-%d").date()
            if tanggal_dt.weekday() >= 5:
                return False, "Tanggal yang dipilih adalah Sabtu atau Minggu, tidak ada jadwal."

            # Ambil semua orang tua
            cursor.execute("SELECT id FROM orang_tua")
            result_orang_tua = cursor.fetchall()
            if not result_orang_tua:
                return False, "Tidak ada orang tua yang terdaftar"
            daftar_orang_tua = [row['id'] for row in result_orang_tua]


            # Ambil semua anak
            cursor.execute("SELECT id, orang_tua_id FROM anak")
            daftar_anak = cursor.fetchall()
            if not daftar_anak:
                return False, "Tidak ada anak yang terdaftar"

            # Hapus jadwal di tanggal yang sama (jika ada)
            cursor.execute("DELETE FROM jadwal WHERE tanggal = %s", (tanggal_dt,))

            # Loop setiap anak
            for anak in daftar_anak:
                anak_id = anak['id']
                ortu_anak_id = anak['orang_tua_id']
                penjemput_id = None 

                # Buat rotasi sederhana
                indeks_hari = tanggal_dt.day % len(daftar_orang_tua)
                calon_penjemput = daftar_orang_tua[indeks_hari:] + daftar_orang_tua[:indeks_hari]

                for calon_id in calon_penjemput:
                    if calon_id == ortu_anak_id:
                        continue
                    cursor.execute("""
                        SELECT 1 FROM tidak_bisa_jemput 
                        WHERE orang_tua_id = %s AND anak_id = %s
                    """, (calon_id, anak_id))
                    if cursor.fetchone() is None:
                        penjemput_id = calon_id
                        break

                if penjemput_id is None:
                    penjemput_id = ortu_anak_id

                cursor.execute("""
                    INSERT INTO jadwal (tanggal, anak_id, penjemput_id)
                    VALUES (%s, %s, %s)
                """, (tanggal_dt, anak_id, penjemput_id))

            # Tambahkan notifikasi
            pesan = f"Jadwal baru untuk tanggal {tanggal} telah dibuat"
            cursor.execute("""
                INSERT INTO notifikasi (pesan, waktu, dibaca)
                VALUES (%s, NOW(), FALSE)
            """, (pesan,))

            connection.commit()
            return True, pesan

        except Exception as e:
            connection.rollback()
            return False, f"Gagal membuat jadwal: {str(e)}"
        
    def buat_jadwal_bulanan(self):
        try:
            bulan = int(self.cmb_bulan.get())
            tahun = int(self.cmb_tahun.get())
            tanggal_awal = int(self.cmb_tanggal_awal.get())
            tanggal_akhir = int(self.cmb_tanggal_akhir.get())
            
            success, msg = self.sistem.buat_jadwal_bulan_dengan_range(bulan, tahun, tanggal_awal, tanggal_akhir)
            if success:
                messagebox.showinfo("Berhasil", msg)
                self.refresh_jadwal_tab()
            else:
                messagebox.showerror("Gagal", msg)
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def tukar_jadwal(self, tanggal, anak_id, dari_orang_tua_id, ke_orang_tua_id):
        """Menukar jadwal penjemputan antara dua orang tua (versi MySQL)"""
        cursor = connection.cursor(dictionary=True)
        try:
            # Cek apakah jadwal untuk tanggal dan anak_id ada
            cursor.execute("""
                SELECT penjemput_id FROM jadwal 
                WHERE tanggal = %s AND anak_id = %s
            """, (tanggal, anak_id))
            hasil = cursor.fetchone()
            if not hasil:
                return False, f"Tidak ada jadwal penjemputan untuk anak ID {anak_id} pada tanggal {tanggal}"

            penjemput_saat_ini = hasil['penjemput_id']
            if penjemput_saat_ini != dari_orang_tua_id:
                return False, f"{dari_orang_tua_id} bukan penjemput anak {anak_id} pada {tanggal}"

            # Cek apakah ke_orang_tua bisa jemput anak_id
            cursor.execute("""
                SELECT 1 FROM tidak_bisa_jemput 
                WHERE orang_tua_id = %s AND anak_id = %s
            """, (ke_orang_tua_id, anak_id))
            if cursor.fetchone():
                return False, f"{ke_orang_tua_id} tidak bisa menjemput anak {anak_id}"

            # Update penjemput di tabel jadwal
            cursor.execute("""
                UPDATE jadwal 
                SET penjemput_id = %s 
                WHERE tanggal = %s AND anak_id = %s
            """, (ke_orang_tua_id, tanggal, anak_id))

            # Tambahkan ke tabel pertukaran (disesuaikan kolom: dari, ke)
            cursor.execute("""
                INSERT INTO pertukaran (tanggal, anak_id, dari, ke, status) 
                VALUES (%s, %s, %s, %s, %s)
            """, (tanggal, anak_id, dari_orang_tua_id, ke_orang_tua_id, "berhasil"))

            # Ambil nama anak dan nama orang tua
            cursor.execute("SELECT nama FROM anak WHERE id = %s", (anak_id,))
            nama_anak = cursor.fetchone()['nama']

            cursor.execute("SELECT nama FROM orang_tua WHERE id = %s", (dari_orang_tua_id,))
            nama_dari = cursor.fetchone()['nama']

            cursor.execute("SELECT nama FROM orang_tua WHERE id = %s", (ke_orang_tua_id,))
            nama_ke = cursor.fetchone()['nama']

            # Tambahkan notifikasi
            pesan = f"Pertukaran jadwal: {nama_anak} pada {tanggal} akan dijemput oleh {nama_ke} menggantikan {nama_dari}"
            cursor.execute("INSERT INTO notifikasi (pesan, waktu, dibaca) VALUES (%s, NOW(), FALSE)", (pesan,))

            connection.commit()
            return True, "Jadwal berhasil ditukar!"
        except Exception as e:
            connection.rollback()
            return False, f"Terjadi kesalahan: {str(e)}"
        finally:
            cursor.close()

    def lihat_jadwal_tanggal(self, tanggal):
        """Melihat jadwal penjemputan pada tanggal tertentu (dari MySQL)"""
        cursor = connection.cursor(dictionary=True)
        try:
            # Ambil semua jadwal di tanggal tersebut
            cursor.execute("""
                SELECT j.anak_id, j.penjemput_id, 
                    a.nama AS nama_anak, 
                    ot.nama AS nama_penjemput
                FROM jadwal j
                JOIN anak a ON j.anak_id = a.id
                JOIN orang_tua ot ON j.penjemput_id = ot.id
                WHERE j.tanggal = %s
            """, (tanggal,))
            hasil_query = cursor.fetchall()

            if not hasil_query:
                return None, f"Tidak ada jadwal untuk tanggal {tanggal}"

            hasil = []
            for row in hasil_query:
                hasil.append((
                    row['nama_anak'],
                    row['nama_penjemput'],
                    row['anak_id'],
                    row['penjemput_id']
                ))

            return hasil, f"Jadwal untuk tanggal {tanggal}"
        except Exception as e:
            return None, f"Terjadi kesalahan: {str(e)}"


    def lihat_jadwal_orang_tua(self, orang_tua_id, bulan=None, tahun=None):
        if not orang_tua_id:
            return None, "ID tidak valid"

        cursor = connection.cursor(dictionary=True)
        query = """
            SELECT j.tanggal, a.nama AS nama_anak,
                CASE WHEN a.orang_tua_id = j.penjemput_id THEN 'Anak Sendiri' ELSE 'Anak Teman' END AS status
            FROM jadwal j
            JOIN anak a ON j.anak_id = a.id
            WHERE j.penjemput_id = %s
        """
        params = [orang_tua_id]

        if bulan and tahun:
            query += " AND MONTH(j.tanggal) = %s AND YEAR(j.tanggal) = %s"
            params += [bulan, tahun]

        query += " ORDER BY j.tanggal ASC"
        cursor.execute(query, params)
        rows = cursor.fetchall()
        cursor.close()

        if not rows:
            return [], "Tidak ada jadwal ditemukan"
        
        hasil = [(row['tanggal'], row['nama_anak'], row['status'], orang_tua_id) for row in rows]
        return hasil, f"Jadwal penjemputan untuk {self.orang_tua[orang_tua_id]['nama']}"


    def lihat_jadwal_anak(self, anak_id, bulan=None, tahun=None):
        if not anak_id:
            return None, "ID tidak valid"

        cursor = connection.cursor(dictionary=True)
        query = """
            SELECT j.tanggal, o.nama AS nama_penjemput,
                CASE WHEN a.orang_tua_id = j.penjemput_id THEN 'Orang Tua' ELSE 'Orang Tua Teman' END AS status
            FROM jadwal j
            JOIN anak a ON j.anak_id = a.id
            JOIN orang_tua o ON j.penjemput_id = o.id
            WHERE j.anak_id = %s
        """
        params = [anak_id]

        if bulan and tahun:
            query += " AND MONTH(j.tanggal) = %s AND YEAR(j.tanggal) = %s"
            params += [bulan, tahun]

        query += " ORDER BY j.tanggal ASC"
        cursor.execute(query, params)
        rows = cursor.fetchall()
        cursor.close()

        if not rows:
            return [], "Tidak ada jadwal ditemukan"

        hasil = [(row['tanggal'], row['nama_penjemput'], row['status'], anak_id) for row in rows]
        return hasil, f"Jadwal penjemputan untuk {self.anak[anak_id]['nama']}"

    def tambah_notifikasi(self, pesan):
        """Menambahkan notifikasi ke database"""
        cursor = connection.cursor()
        try:
            cursor.execute("""
                INSERT INTO notifikasi (pesan, waktu, dibaca)
                VALUES (%s, NOW(), FALSE)
            """, (pesan,))
            connection.commit()
        except Exception as e:
            print(f"Gagal menambahkan notifikasi: {str(e)}")


    def lihat_notifikasi(self, hanya_belum_dibaca=False):
        """Mengambil daftar notifikasi dari database"""
        cursor = connection.cursor(dictionary=True)
        try:
            if hanya_belum_dibaca:
                cursor.execute("""
                    SELECT id, pesan, waktu, dibaca 
                    FROM notifikasi 
                    WHERE dibaca = FALSE
                    ORDER BY waktu DESC
                """)
            else:
                cursor.execute("""
                    SELECT id, pesan, waktu, dibaca 
                    FROM notifikasi 
                    ORDER BY waktu DESC
                """)

            hasil = []
            for notif in cursor.fetchall():
                status = "Baru" if not notif['dibaca'] else "Dibaca"
                waktu = notif['waktu']
                waktu_str = waktu.strftime("%Y-%m-%d %H:%M:%S") if waktu else "Unknown"
                hasil.append((status, waktu_str, notif['pesan']))

            # Tandai sebagai dibaca
            if hanya_belum_dibaca:
                cursor.execute("UPDATE notifikasi SET dibaca = TRUE WHERE dibaca = FALSE")
                connection.commit()

            if not hasil:
                return [], "Tidak ada notifikasi baru" if hanya_belum_dibaca else "Tidak ada notifikasi"

            return hasil, "Daftar Notifikasi"
        except Exception as e:
            return [], f"Terjadi kesalahan: {str(e)}"


    def simpan_data(self):
        """Menyimpan data ke file JSON"""
        data = {
            "orang_tua": self.orang_tua,
            "anak": self.anak,
            "jadwal": self.jadwal,
            "notifikasi": self.notifikasi,
            "pertukaran": self.pertukaran
        }
        
        try:
            with open("data_penjadwalan_jemput.json", "w") as file:
                json.dump(data, file, indent=4)
            return True
        except Exception as e:
            print(f"Error menyimpan data: {str(e)}")
            return False
        
    def muat_data(self):
        cursor = connection.cursor(dictionary=True)

        # Muat orang tua
        cursor.execute("SELECT * FROM orang_tua")
        self.orang_tua = {row["id"]: {"nama": row["nama"], "anak": [], "tidak_bisa_jemput": []} for row in cursor.fetchall()}

        # Muat anak
        cursor.execute("SELECT * FROM anak")
        self.anak = {}
        for row in cursor.fetchall():
            self.anak[row["id"]] = {"nama": row["nama"], "orang_tua_id": row["orang_tua_id"]}
            self.orang_tua[row["orang_tua_id"]]["anak"].append(row["id"])

        # Muat tidak bisa jemput
        cursor.execute("SELECT * FROM tidak_bisa_jemput")
        for row in cursor.fetchall():
            self.orang_tua[row["orang_tua_id"]]["tidak_bisa_jemput"].append(row["anak_id"])

        # Muat jadwal
        cursor.execute("SELECT * FROM jadwal")
        self.jadwal = {}
        for row in cursor.fetchall():
            tgl = row["tanggal"].strftime("%Y-%m-%d")
            if tgl not in self.jadwal:
                self.jadwal[tgl] = {}
            self.jadwal[tgl][row["anak_id"]] = row["penjemput_id"]

        # Muat notifikasi
        cursor.execute("SELECT * FROM notifikasi ORDER BY waktu DESC")
        self.notifikasi = []
        for row in cursor.fetchall():
            waktu = row["waktu"]
            self.notifikasi.append({
                "pesan": row["pesan"],
                "waktu": waktu.strftime("%Y-%m-%d %H:%M:%S") if waktu else "Unknown",
                "dibaca": bool(row["dibaca"])
            })

        # Muat pertukaran
        cursor.execute("SELECT * FROM pertukaran")
        self.pertukaran = []
        for row in cursor.fetchall():
            waktu_pertukaran = row["waktu_pertukaran"]
            self.pertukaran.append({
                "tanggal": row["tanggal"].strftime("%Y-%m-%d") if row["tanggal"] else "Unknown",
                "anak_id": row["anak_id"],
                "dari": row["dari"],
                "ke": row["ke"],
                "waktu_pertukaran": waktu_pertukaran.strftime("%Y-%m-%d %H:%M:%S") if waktu_pertukaran else "Unknown"
            })


        cursor.close()
    
    def get_daftar_orang_tua_id_nama(self):
        """Mengambil daftar ID dan nama orang tua dari database"""
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT id, nama FROM orang_tua ORDER BY nama")
            return cursor.fetchall()
        except Exception as e:
            print(f"Gagal mengambil data orang tua: {str(e)}")
            return []

    def get_daftar_anak_id_nama(self):
        """Mengambil daftar ID dan nama anak dari database"""
        cursor = connection.cursor()
        try:
            cursor.execute("SELECT id, nama FROM anak ORDER BY nama")
            return cursor.fetchall()
        except Exception as e:
            print(f"Gagal mengambil data anak: {str(e)}")
            return []


    def get_riwayat_pertukaran(self):
        """Mendapatkan riwayat pertukaran jadwal"""
        hasil = []
        for tukar in self.pertukaran:
            tanggal = tukar["tanggal"]
            nama_anak = self.anak[tukar["anak_id"]]["nama"] if tukar["anak_id"] in self.anak else "?"
            dari_nama = self.orang_tua[tukar["dari"]]["nama"] if tukar["dari"] in self.orang_tua else "?"
            ke_nama = self.orang_tua[tukar["ke"]]["nama"] if tukar["ke"] in self.orang_tua else "?"
            waktu = tukar["waktu_pertukaran"]
            
            hasil.append((tanggal, nama_anak, dari_nama, ke_nama, waktu))
        
        return hasil

class SistemJemputGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        
        self.title("Sistem Penjadwalan Jemput Anak Sekolah")
        self.geometry("1200x800")
        self.minsize(1000, 600)
        
        # Style configuration
        self.style = ttk.Style()
        self.style.configure('TFrame', background='#f0f0f0')
        self.style.configure('TLabel', background='#f0f0f0', font=('Helvetica', 10))
        self.style.configure('TButton', font=('Helvetica', 10))
        self.style.configure('Header.TLabel', font=('Helvetica', 12, 'bold'))
        
        # Inisialisasi sistem
        self.sistem = SistemPenjadwalanJemput()
        
        # Setup GUI
        self.setup_gui()
        self.periksa_notifikasi()

    def setup_gui(self):
        # Buat notebook untuk tab
        self.tabControl = ttk.Notebook(self)
        
        # Buat frame untuk setiap tab
        self.tab_beranda = ttk.Frame(self.tabControl)
        self.tab_orang_tua = ttk.Frame(self.tabControl)
        self.tab_anak = ttk.Frame(self.tabControl)
        self.tab_jadwal = ttk.Frame(self.tabControl)
        self.tab_notifikasi = ttk.Frame(self.tabControl)
        
        # Tambahkan tab
        self.tabControl.add(self.tab_beranda, text="🏠 Beranda")
        self.tabControl.add(self.tab_orang_tua, text="👨‍👩‍👧 Orang Tua")
        self.tabControl.add(self.tab_anak, text="👶 Anak")
        self.tabControl.add(self.tab_jadwal, text="📅 Jadwal")
        self.tabControl.add(self.tab_notifikasi, text="🔔 Notifikasi")
        
        self.tabControl.pack(expand=1, fill="both")
        
        # Setup masing-masing tab
        self.setup_tab_beranda()
        self.setup_tab_orang_tua()
        self.setup_tab_anak()
        self.setup_tab_jadwal()
        self.setup_tab_notifikasi()
        
        self.tabControl.bind("<<NotebookTabChanged>>", self.on_tab_changed)
        
        self.refresh_beranda()
        self.refresh_orang_tua()
        self.refresh_anak()
        self.refresh_jadwal_tab()
        self.refresh_notifikasi()
    
    def on_tab_changed(self, event):
        current_tab = self.tabControl.tab(self.tabControl.select(), "text")
        if current_tab == "🔔 Notifikasi":
            self.refresh_notifikasi()

    def tambah_orang_tua(self):
        try:
            ot_id = self.entry_ot_id.get()
            nama = self.entry_ot_nama.get()
            
            if not ot_id or not nama:
                messagebox.showerror("Error", "ID dan Nama harus diisi!")
                return
                
            success, msg = self.sistem.tambah_orang_tua(ot_id, nama)
            if success:
                messagebox.showinfo("Berhasil", msg)
                self.sistem.muat_data()  # <-- ini penting
                self.refresh_orang_tua()
                self.refresh_beranda()
                self.update_combobox_orang_tua()
            else:
                messagebox.showerror("Gagal", msg)
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")


    def setup_tab_beranda(self):
        # Frame utama dengan background
        main_frame = ttk.Frame(self.tab_beranda)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Panel statistik dengan border dan padding
        stats_frame = ttk.LabelFrame(main_frame, text="Statistik Sistem", padding=15)
        stats_frame.pack(fill="x", pady=5)

        # Variabel statistik dengan style berbeda
        self.stats_orang_tua = tk.StringVar(value="Jumlah Orang Tua: 0")
        self.stats_anak = tk.StringVar(value="Jumlah Anak: 0")
        self.stats_jadwal = tk.StringVar(value="Jadwal Aktif: 0")
        self.stats_notifikasi = tk.StringVar(value="Notifikasi Baru: 0")
        
        # Tampilkan statistik di GUI dengan style berbeda
        ttk.Label(stats_frame, textvariable=self.stats_orang_tua, font=("Helvetica", 10, "bold"), foreground="blue").pack(side=tk.LEFT, padx=20)
        ttk.Label(stats_frame, textvariable=self.stats_anak, font=("Helvetica", 10, "bold"), foreground="green").pack(side=tk.LEFT, padx=20)
        ttk.Label(stats_frame, textvariable=self.stats_jadwal, font=("Helvetica", 10, "bold"), foreground="orange").pack(side=tk.LEFT, padx=20)
        ttk.Label(stats_frame, textvariable=self.stats_notifikasi, font=("Helvetica", 10, "bold"), foreground="red").pack(side=tk.LEFT, padx=20)

        # Panel jadwal hari ini dengan style
        jadwal_frame = ttk.LabelFrame(main_frame, text="📅 Jadwal Hari Ini", padding=10)
        jadwal_frame.pack(fill="both", expand=True, pady=5)

        # Treeview jadwal hari ini dengan style
        self.tv_jadwal_hari_ini = ttk.Treeview(jadwal_frame, 
                                            columns=("anak", "penjemput", "status"), 
                                            show="headings",
                                            height=8)
        self.tv_jadwal_hari_ini.heading("anak", text="Nama Anak")
        self.tv_jadwal_hari_ini.heading("penjemput", text="Penjemput")
        self.tv_jadwal_hari_ini.heading("status", text="Status")
        self.tv_jadwal_hari_ini.column("anak", width=150, anchor=tk.W)
        self.tv_jadwal_hari_ini.column("penjemput", width=150, anchor=tk.W)
        self.tv_jadwal_hari_ini.column("status", width=100, anchor=tk.CENTER)
        
        # Tambahkan scrollbar
        scrollbar = ttk.Scrollbar(jadwal_frame, orient="vertical", command=self.tv_jadwal_hari_ini.yview)
        scrollbar.pack(side="right", fill="y")
        self.tv_jadwal_hari_ini.configure(yscrollcommand=scrollbar.set)
        self.tv_jadwal_hari_ini.pack(fill="both", expand=True)

        # Panel notifikasi terbaru dengan style
        notif_frame = ttk.LabelFrame(main_frame, text="🔔 Notifikasi Terbaru", padding=10)
        notif_frame.pack(fill="both", expand=True, pady=5)

        # Treeview notifikasi dengan style
        self.tv_notifikasi_terbaru = ttk.Treeview(notif_frame, 
                                                columns=("status", "waktu", "pesan"), 
                                                show="headings",
                                                height=5)
        self.tv_notifikasi_terbaru.heading("status", text="Status")
        self.tv_notifikasi_terbaru.heading("waktu", text="Waktu")
        self.tv_notifikasi_terbaru.heading("pesan", text="Pesan")
        self.tv_notifikasi_terbaru.column("status", width=80, anchor=tk.CENTER)
        self.tv_notifikasi_terbaru.column("waktu", width=120, anchor=tk.CENTER)
        self.tv_notifikasi_terbaru.column("pesan", width=400, anchor=tk.W)
        
        # Tambahkan scrollbar
        scrollbar = ttk.Scrollbar(notif_frame, orient="vertical", command=self.tv_notifikasi_terbaru.yview)
        scrollbar.pack(side="right", fill="y")
        self.tv_notifikasi_terbaru.configure(yscrollcommand=scrollbar.set)
        self.tv_notifikasi_terbaru.pack(fill="both", expand=True)

        # Tombol refresh dengan style
        refresh_btn = ttk.Button(main_frame, text="🔄 Refresh Data", command=self.refresh_beranda)
        refresh_btn.pack(pady=10)

        # Inisialisasi data pertama kali
        self.refresh_beranda()

    def setup_tab_orang_tua(self):
        main_frame = ttk.Frame(self.tab_orang_tua)
        main_frame.pack(fill="both", expand=True)

        # Panel kiri - Form tambah orang tua dengan style
        left_frame = ttk.Frame(main_frame)
        left_frame.pack(side="left", fill="y", padx=10, pady=10)
        
        form_frame = ttk.LabelFrame(left_frame, text="➕ Form Registrasi Orang Tua", padding=15)
        form_frame.pack(pady=10)
        
        # Input ID dengan style
        ttk.Label(form_frame, text="ID Orang Tua:").grid(row=0, column=0, sticky="w", pady=5)
        self.entry_ot_id = ttk.Entry(form_frame)
        self.entry_ot_id.grid(row=0, column=1, pady=5, padx=5)
        
        # Input Nama dengan style
        ttk.Label(form_frame, text="Nama Orang Tua:").grid(row=1, column=0, sticky="w", pady=5)
        self.entry_ot_nama = ttk.Entry(form_frame)
        self.entry_ot_nama.grid(row=1, column=1, pady=5, padx=5)
        
        # Tombol Tambah dengan style
        ttk.Button(form_frame, text="Tambah", command=self.tambah_orang_tua, style="Accent.TButton").grid(row=2, column=0, columnspan=2, pady=10)

        # Panel kanan - Daftar orang tua dengan style
        right_frame = ttk.Frame(main_frame)
        right_frame.pack(side="right", fill="both", expand=True, padx=10, pady=10)
        
        # Treeview untuk daftar orang tua dengan style
        self.tv_orang_tua = ttk.Treeview(right_frame, 
                                       columns=("id", "nama", "jumlah_anak"), 
                                       show="headings",
                                       height=15)
        self.tv_orang_tua.heading("id", text="ID")
        self.tv_orang_tua.heading("nama", text="Nama")
        self.tv_orang_tua.heading("jumlah_anak", text="Jumlah Anak")
        self.tv_orang_tua.column("id", width=100)
        self.tv_orang_tua.column("nama", width=150)
        self.tv_orang_tua.column("jumlah_anak", width=100)
        
        # Tambahkan scrollbar
        scrollbar = ttk.Scrollbar(right_frame, orient="vertical", command=self.tv_orang_tua.yview)
        scrollbar.pack(side="right", fill="y")
        self.tv_orang_tua.configure(yscrollcommand=scrollbar.set)
        self.tv_orang_tua.pack(fill="both", expand=True, padx=5, pady=5)
        
        # Context menu
        self.ot_menu = tk.Menu(self.tv_orang_tua, tearoff=0)
        self.ot_menu.add_command(label="Lihat Detail", command=self.lihat_detail_orang_tua)
        self.tv_orang_tua.bind("<Button-3>", self.show_ot_context_menu)
        
        self.refresh_orang_tua()

    def setup_tab_jadwal(self):
        main_frame = ttk.Frame(self.tab_jadwal)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Date selection untuk lihat jadwal
        date_frame = ttk.LabelFrame(main_frame, text="📅 Pilih Tanggal", padding=10)
        date_frame.pack(pady=10, fill="x")

        ttk.Label(date_frame, text="Tanggal:").pack(side=tk.LEFT)
        self.day_var = tk.StringVar()
        self.day_cb = ttk.Combobox(date_frame, textvariable=self.day_var, width=3)
        self.day_cb['values'] = [str(i).zfill(2) for i in range(1, 32)]
        self.day_cb.pack(side=tk.LEFT, padx=5)

        ttk.Label(date_frame, text="Bulan:").pack(side=tk.LEFT)
        self.month_var = tk.StringVar()
        self.month_cb = ttk.Combobox(date_frame, textvariable=self.month_var, width=3)
        self.month_cb['values'] = [str(i).zfill(2) for i in range(1, 13)]
        self.month_cb.pack(side=tk.LEFT, padx=5)

        ttk.Label(date_frame, text="Tahun:").pack(side=tk.LEFT)
        self.year_var = tk.StringVar()
        self.year_cb = ttk.Combobox(date_frame, textvariable=self.year_var, width=5)
        self.year_cb['values'] = [str(i) for i in range(2020, 2031)]
        self.year_cb.pack(side=tk.LEFT, padx=5)

        ttk.Button(date_frame, text="🔍 Lihat Jadwal", command=self.tanggal_dipilih).pack(side=tk.LEFT, padx=10)

        # Control frame untuk pembuatan jadwal pada 1 tanggal
        control_frame = ttk.LabelFrame(main_frame, text="📅 Buat Jadwal untuk Tanggal", padding=10)
        control_frame.pack(fill='x', pady=10)

        ttk.Label(control_frame, text="Tanggal:").pack(side=tk.LEFT, padx=5)
        self.cmb_tanggal = ttk.Combobox(control_frame, values=list(range(1, 32)), width=3, state="readonly")
        self.cmb_tanggal.pack(side=tk.LEFT, padx=5)
        self.cmb_tanggal.set(datetime.datetime.now().day)

        ttk.Label(control_frame, text="Bulan:").pack(side=tk.LEFT, padx=5)
        self.cmb_bulan = ttk.Combobox(control_frame, values=list(range(1, 13)), width=3, state="readonly")
        self.cmb_bulan.pack(side=tk.LEFT, padx=5)
        self.cmb_bulan.set(datetime.datetime.now().month)

        ttk.Label(control_frame, text="Tahun:").pack(side=tk.LEFT, padx=5)
        self.cmb_tahun = ttk.Combobox(control_frame, values=list(range(2020, 2031)), width=5, state="readonly")
        self.cmb_tahun.pack(side=tk.LEFT, padx=5)
        self.cmb_tahun.set(datetime.datetime.now().year)

        # Tombol buat jadwal untuk tanggal spesifik
        ttk.Button(control_frame, text="📅 Buat Jadwal", command=self.buat_jadwal_tanggal).pack(side=tk.LEFT, padx=10)

        # Tampilkan daftar jadwal
        self.tv_jadwal = ttk.Treeview(main_frame, columns=("Anak", "Penjemput"), show="headings", height=10)
        self.tv_jadwal.heading("Anak", text="Nama Anak")
        self.tv_jadwal.heading("Penjemput", text="Penjemput")
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=self.tv_jadwal.yview)
        scrollbar.pack(side="right", fill="y")
        self.tv_jadwal.configure(yscrollcommand=scrollbar.set)
        self.tv_jadwal.pack(fill="both", expand=True, padx=5, pady=5)

        # Form pertukaran jadwal
        swap_frame = ttk.LabelFrame(main_frame, text="🔄 Ajukan Pertukaran Jadwal", padding=10)
        swap_frame.pack(fill="x", pady=10)

        ttk.Label(swap_frame, text="Anak:").grid(row=0, column=0, sticky="w", pady=5)
        self.cmb_anak_swap = ttk.Combobox(swap_frame, state="readonly")
        self.cmb_anak_swap.grid(row=0, column=1, padx=5, pady=5)

        ttk.Label(swap_frame, text="Dari Orang Tua:").grid(row=1, column=0, sticky="w", pady=5)
        self.cmb_dari_ot = ttk.Combobox(swap_frame, state="readonly")
        self.cmb_dari_ot.grid(row=1, column=1, padx=5, pady=5)

        ttk.Label(swap_frame, text="Ke Orang Tua:").grid(row=2, column=0, sticky="w", pady=5)
        self.cmb_ke_ot = ttk.Combobox(swap_frame, state="readonly")
        self.cmb_ke_ot.grid(row=2, column=1, padx=5, pady=5)

        ttk.Button(swap_frame, text="Ajukan Pertukaran", command=self.ajukan_pertukaran).grid(row=3, column=0, columnspan=2, pady=5)

        # Set default date
        now = datetime.datetime.now()
        self.day_var.set(str(now.day).zfill(2))
        self.month_var.set(str(now.month).zfill(2))
        self.year_var.set(str(now.year))

        self.refresh_jadwal_tab()
        
    def buat_jadwal_tanggal(self):
        try:
            tanggal = int(self.cmb_tanggal.get())
            bulan = int(self.cmb_bulan.get())
            tahun = int(self.cmb_tahun.get())
            tanggal_obj = datetime.date(tahun, bulan, tanggal)

            # Gunakan method yang benar
            success, msg = self.sistem.buat_jadwal_tanggal(tanggal_obj.strftime("%Y-%m-%d"))
            if success:
                messagebox.showinfo("Berhasil", msg)
                self.refresh_jadwal_tab()
            else:
                messagebox.showerror("Gagal", msg)
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def setup_tab_notifikasi(self):
        main_frame = ttk.Frame(self.tab_notifikasi)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Toolbar dengan style
        toolbar = ttk.Frame(main_frame)
        toolbar.pack(fill="x", pady=5)
        
        ttk.Button(toolbar, text="✓ Tandai Semua Terbaca", 
                 command=self.tandai_semua_terbaca).pack(side="left", padx=5)
        ttk.Button(toolbar, text="🗑️ Hapus Notifikasi", 
                 command=self.hapus_notifikasi).pack(side="left", padx=5)

        # Treeview notifikasi dengan style
        self.tv_notifikasi = ttk.Treeview(main_frame, 
                                        columns=("status", "waktu", "pesan"), 
                                        show="headings",
                                        height=15)
        self.tv_notifikasi.heading("status", text="Status")
        self.tv_notifikasi.heading("waktu", text="Waktu")
        self.tv_notifikasi.heading("pesan", text="Pesan")
        self.tv_notifikasi.column("status", width=80)
        self.tv_notifikasi.column("waktu", width=120)
        self.tv_notifikasi.column("pesan", width=400)
        
        # Tambahkan scrollbar
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=self.tv_notifikasi.yview)
        scrollbar.pack(side="right", fill="y")
        self.tv_notifikasi.configure(yscrollcommand=scrollbar.set)
        self.tv_notifikasi.pack(fill="both", expand=True)

    def refresh_beranda(self):
        # Update statistik
        self.sistem.muat_data()  # <-- ini penting
        self.stats_orang_tua.set(f"Jumlah Orang Tua: {len(self.sistem.orang_tua)}") 
        self.stats_anak.set(f"Jumlah Anak: {len(self.sistem.anak)}")

        # Update statistik
        self.stats_orang_tua.set(f"Jumlah Orang Tua: {len(self.sistem.orang_tua)}") 
        self.stats_anak.set(f"Jumlah Anak: {len(self.sistem.anak)}")
        
        # Hitung jadwal aktif
        today = date.today().strftime("%Y-%m-%d")
        jadwal_aktif = sum(1 for tgl in self.sistem.jadwal if tgl >= today)
        self.stats_jadwal.set(f"Jadwal Aktif: {jadwal_aktif}")
        
        # Hitung notifikasi baru
        notif_baru = sum(1 for notif in self.sistem.notifikasi if not notif["dibaca"])
        self.stats_notifikasi.set(f"Notifikasi Baru: {notif_baru}")
        
        # Update jadwal hari ini
        for i in self.tv_jadwal_hari_ini.get_children():
            self.tv_jadwal_hari_ini.delete(i)
        
        jadwal_hari_ini, _ = self.sistem.lihat_jadwal_tanggal(today)
        if jadwal_hari_ini:
            for nama_anak, nama_penjemput, anak_id, penjemput_id in jadwal_hari_ini:
                status = "Anak Sendiri" if self.sistem.anak[anak_id]['orang_tua_id'] == penjemput_id else "Anak Teman"
                self.tv_jadwal_hari_ini.insert("", "end", values=(nama_anak, nama_penjemput, status))
        else:
            self.tv_jadwal_hari_ini.insert("", "end", values=("Tidak ada jadwal penjemputan pada hari ini.", "", ""))
        
        # Update notifikasi
        for i in self.tv_notifikasi_terbaru.get_children():
            self.tv_notifikasi_terbaru.delete(i)
        
        notifikasi, _ = self.sistem.lihat_notifikasi()
        for status, waktu, pesan in notifikasi[:5]:  # Ambil 5 terbaru
            self.tv_notifikasi_terbaru.insert("", "end", values=(status, waktu, pesan))

    def refresh_orang_tua(self):
        for i in self.tv_orang_tua.get_children():
            self.tv_orang_tua.delete(i)
        
        for ot_id, data in self.sistem.orang_tua.items():
            jumlah_anak = len(data.get("anak", []))
            self.tv_orang_tua.insert("", "end", values=(ot_id, data["nama"], jumlah_anak))


    def periksa_notifikasi(self):
        notif_baru = sum(1 for notif in self.sistem.notifikasi if not notif["dibaca"])
        if notif_baru > 0:
            self.tabControl.tab(4, text="🔔 Notifikasi (!)")
        else:
            self.tabControl.tab(4, text="🔔 Notifikasi")
        self.after(5000, self.periksa_notifikasi)

    def setup_tab_anak(self):
        main_frame = ttk.Frame(self.tab_anak)
        main_frame.pack(fill="both", expand=True, padx=10, pady=10)

        # Form tambah anak dengan style
        form_frame = ttk.LabelFrame(main_frame, text="➕ Tambah Anak", padding=15)
        form_frame.pack(fill="x", padx=10, pady=10)

        ttk.Label(form_frame, text="ID Anak:").grid(row=0, column=0, pady=5)
        self.entry_anak_id = ttk.Entry(form_frame)
        self.entry_anak_id.grid(row=0, column=1, pady=5, padx=5)

        ttk.Label(form_frame, text="Nama Anak:").grid(row=1, column=0, pady=5)
        self.entry_anak_nama = ttk.Entry(form_frame)
        self.entry_anak_nama.grid(row=1, column=1, pady=5, padx=5)

        ttk.Label(form_frame, text="Orang Tua ID:").grid(row=2, column=0, pady=5)
        self.cmb_orang_tua = ttk.Combobox(form_frame)
        self.cmb_orang_tua.grid(row=2, column=1, pady=5, padx=5)
        self.update_combobox_orang_tua()

        # Tombol Tambah Anak dengan style
        ttk.Button(form_frame, text="Tambah Anak", command=self.tambah_anak).grid(row=3, column=0, columnspan=2, pady=10)

        # Daftar anak dengan style
        self.tv_anak = ttk.Treeview(main_frame, 
                                  columns=("id", "nama", "orang_tua"), 
                                  show="headings",
                                  height=15)
        self.tv_anak.heading("id", text="ID")
        self.tv_anak.heading("nama", text="Nama")
        self.tv_anak.heading("orang_tua", text="Orang Tua")
        
        # Tambahkan scrollbar
        scrollbar = ttk.Scrollbar(main_frame, orient="vertical", command=self.tv_anak.yview)
        scrollbar.pack(side="right", fill="y")
        self.tv_anak.configure(yscrollcommand=scrollbar.set)
        self.tv_anak.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.refresh_anak()

    def tambah_anak(self):
        try:
            anak_id = self.entry_anak_id.get()
            nama = self.entry_anak_nama.get()
            orang_tua_str = self.cmb_orang_tua.get()
            if not orang_tua_str:
                messagebox.showerror("Error", "Pilih orang tua!")
                return
            orang_tua_id = orang_tua_str.split(" - ")[0]
            
            if not anak_id or not nama:
                messagebox.showerror("Error", "ID dan Nama harus diisi!")
                return
                
            success, msg = self.sistem.tambah_anak(anak_id, nama, orang_tua_id)
            if success:
                messagebox.showinfo("Berhasil", msg)
                self.sistem.muat_data()  # <-- update dari DB
                self.refresh_anak()
                self.update_combobox_orang_tua()
                self.refresh_beranda()
            else:
                messagebox.showerror("Gagal", msg)
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    
    def update_combobox_orang_tua(self):
        try:
            values = [f"{id} - {data['nama']}" for id, data in self.sistem.orang_tua.items()]
            self.cmb_orang_tua['values'] = values
            if values:
                self.cmb_orang_tua.current(0)
        except Exception as e:
            messagebox.showerror("Error", f"Gagal memuat data orang tua: {str(e)}")


    def refresh_anak(self):
        for i in self.tv_anak.get_children():
            self.tv_anak.delete(i)
        
        for anak_id, data in self.sistem.anak.items():
            orang_tua = self.sistem.orang_tua.get(data["orang_tua_id"], {}).get("nama", "Tidak diketahui")
            self.tv_anak.insert("", "end", values=(anak_id, data["nama"], orang_tua))


    def tanggal_dipilih(self, event=None):
        try:
            day = self.day_var.get()
            month = self.month_var.get()
            year = self.year_var.get()
            
            if not day or not month or not year:
                messagebox.showerror("Error", "Harap pilih tanggal, bulan, dan tahun!")
                return
                
            selected_date = f"{year}-{month}-{day}"
            
            # Validasi tanggal
            datetime.datetime.strptime(selected_date, "%Y-%m-%d")
            
            jadwal, _ = self.sistem.lihat_jadwal_tanggal(selected_date)
            # Hapus data lama
            for item in self.tv_jadwal.get_children():
                self.tv_jadwal.delete(item)
                
            # Tambahkan data baru
            for nama_anak, nama_penjemput, anak_id, penjemput_id in jadwal:
                self.tv_jadwal.insert("", "end", values=(nama_anak, nama_penjemput))
                
            # Update combo boxes for swap
            self.cmb_anak_swap['values'] = [f"{anak_id} - {nama_anak}" for nama_anak, _, anak_id, _ in jadwal]
            self.cmb_dari_ot['values'] = [f"{penjemput_id} - {nama_penjemput}" for _, nama_penjemput, _, penjemput_id in jadwal]
            self.cmb_ke_ot['values'] = [f"{id} - {nama}" for id, nama in self.sistem.get_daftar_orang_tua_id_nama()]
            
            if jadwal:
                self.cmb_anak_swap.current(0)
                self.cmb_dari_ot.current(0)
                if self.cmb_ke_ot['values']:
                    self.cmb_ke_ot.current(0)
                    
        except ValueError:
            messagebox.showerror("Error", "Tanggal tidak valid!")
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")
            
    def ajukan_pertukaran(self):
        try:
            # Get selected date from comboboxes
            day = self.day_var.get()
            month = self.month_var.get()
            year = self.year_var.get()
            tanggal = f"{year}-{month}-{day}"
            
            anak_id = self.cmb_anak_swap.get().split(" - ")[0]
            dari_ot = self.cmb_dari_ot.get().split(" - ")[0]
            ke_ot = self.cmb_ke_ot.get().split(" - ")[0]
            
            success, msg = self.sistem.tukar_jadwal(tanggal, anak_id, dari_ot, ke_ot)
            if success:
                messagebox.showinfo("Berhasil", msg)
                self.refresh_jadwal_tab()
            else:
                messagebox.showerror("Gagal", msg)
        except Exception as e:
            messagebox.showerror("Error", f"Terjadi kesalahan: {str(e)}")

    def refresh_jadwal_tab(self):
        # Refresh date display
        self.tanggal_dipilih()
        
        # Refresh combo boxes
        try:
            self.cmb_anak_swap["values"] = [f"{id} - {nama}" for id, nama in self.sistem.get_daftar_anak_id_nama()]
            self.cmb_dari_ot["values"] = [f"{id} - {nama}" for id, nama in self.sistem.get_daftar_orang_tua_id_nama()]
            self.cmb_ke_ot["values"] = [f"{id} - {nama}" for id, nama in self.sistem.get_daftar_orang_tua_id_nama()]
        except Exception as e:
            messagebox.showerror("Error", f"Gagal memuat data: {str(e)}")

    def refresh_notifikasi(self):
        for i in self.tv_notifikasi.get_children():
            self.tv_notifikasi.delete(i)
        
        notifikasi, _ = self.sistem.lihat_notifikasi()
        for status, waktu, pesan in notifikasi:
            self.tv_notifikasi.insert("", "end", values=(status, waktu, pesan))

    def tandai_semua_terbaca(self):
        cursor = connection.cursor()
        try:
            cursor.execute("UPDATE notifikasi SET dibaca = TRUE")
            connection.commit()
        except Exception as e:
            print(f"Gagal tandai notifikasi: {str(e)}")

    def hapus_notifikasi(self):
        cursor = connection.cursor()
        cursor.execute("DELETE FROM notifikasi")
        connection.commit()
        cursor.close()
        self.notifikasi = []
        self.refresh_notifikasi()

    def show_ot_context_menu(self, event):
        item = self.tv_orang_tua.identify_row(event.y)
        if item:
            self.tv_orang_tua.selection_set(item)
            self.ot_menu.post(event.x_root, event.y_root)

    def lihat_detail_orang_tua(self):
        selected_item = self.tv_orang_tua.selection()
        if selected_item:
            item = self.tv_orang_tua.item(selected_item)
            ot_id = item["values"][0]
            # Tampilkan detail orang tua di messagebox
            detail = f"ID: {ot_id}\nNama: {self.sistem.orang_tua[ot_id]['nama']}\n"
            detail += f"Jumlah Anak: {len(self.sistem.orang_tua[ot_id]['anak'])}\n"
            detail += f"Tidak Bisa Jemput: {len(self.sistem.orang_tua[ot_id]['tidak_bisa_jemput'])} anak"
            messagebox.showinfo("Detail Orang Tua", detail)

if __name__ == "__main__":
    try:
        app = SistemJemputGUI()
    
        app.mainloop()
    except Exception as e:
        messagebox.showerror("Fatal Error", f"Terjadi kesalahan: {str(e)}")
        sys.exit(1)