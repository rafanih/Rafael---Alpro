-- 1. Tabel orang_tua
CREATE TABLE IF NOT EXISTS orang_tua (
    id VARCHAR(10) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL
);

-- 2. Tabel anak
CREATE TABLE IF NOT EXISTS anak (
    id VARCHAR(10) PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    orang_tua_id VARCHAR(10),
    FOREIGN KEY (orang_tua_id) REFERENCES orang_tua(id)
);

-- 3. Tabel jadwal
CREATE TABLE IF NOT EXISTS jadwal (
    tanggal DATE,
    anak_id VARCHAR(10),
    penjemput_id VARCHAR(10),
    PRIMARY KEY (tanggal, anak_id),
    FOREIGN KEY (anak_id) REFERENCES anak(id),
    FOREIGN KEY (penjemput_id) REFERENCES orang_tua(id)
);

-- 4. Tabel tidak_bisa_jemput
CREATE TABLE IF NOT EXISTS tidak_bisa_jemput (
    orang_tua_id VARCHAR(10),
    anak_id VARCHAR(10),
    PRIMARY KEY (orang_tua_id, anak_id),
    FOREIGN KEY (orang_tua_id) REFERENCES orang_tua(id),
    FOREIGN KEY (anak_id) REFERENCES anak(id)
);

-- 5. Tabel notifikasi
CREATE TABLE IF NOT EXISTS notifikasi (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pesan TEXT NOT NULL,
    waktu DATETIME,
    dibaca BOOLEAN DEFAULT FALSE
);

-- 6. Tabel pertukaran
CREATE TABLE IF NOT EXISTS pertukaran (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tanggal DATE,
    anak_id VARCHAR(10),
    dari VARCHAR(10),
    ke VARCHAR(10),
    status VARCHAR(20),
    waktu_pertukaran DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (anak_id) REFERENCES anak(id),
    FOREIGN KEY (dari) REFERENCES orang_tua(id),
    FOREIGN KEY (ke) REFERENCES orang_tua(id)
);
